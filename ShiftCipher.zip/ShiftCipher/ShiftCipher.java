import java.util.*;
import java.io.*;
/**
 * This ShiftCipher class encrypts or decrypts an input file and provides the relevant result in an output file of user's choice.
 * The class also has a bruteforce method that will test all 26 possible keys for decryption
 * then print the results to screen that have a dictionary accuracy of atleast 70%
 * @authors: Nicole Abuzo and Henry Hetzel
 * @date: 2/9/2020
 */
public class ShiftCipher
{
    public static void main(String[] args) throws IOException
    {
        ArrayList<String> possibleKeys = new ArrayList<String>(); 
        for(int i = 0; i < 26; i++){ //the secret key can only be 0-25
            possibleKeys.add(Integer.toString(i)); //read the integer into a string
        }
        
        if (args.length != 4){ //This if statement catches if the user inputs an incorrect number of arguments and exits the program.
            System.out.println("You have entered an incorrect number of arguments.\nPlease enter:\n1. (-e (encrypt),-d (decrypt),-c (bruteforce crack))\n2. input file\n3. integer key\n4. output file");
        }
        else{
            if(args[0].equals("-e") || args[0].equals("-d") || args[0].equals("-c")){ //ensure that arguments are these letter types
                if (possibleKeys.contains(args[2])){ //if the secret key is in the array of possible keys
                    try{
                        String type = args[0]; // this argument takes (-e, -d, -c)
                        String inputFile = args[1]; // must be a string, if not catch it
                        int key;  //key must be a number, catch error when its not a number
                        key = Integer.parseInt(args[2]); //must change from string to int
                        String outputFile = args[3]; //output filename coming from the user
                
                        //read the file and store the characters as an array into the empty variable
                        FileReader file = new FileReader(inputFile);
                        BufferedReader reader = new BufferedReader(file);
                        String data = ""; //empty 
                        String line = reader.readLine();
                        while (line != null){
                            data += line;
                            line = reader.readLine();
                        }
                        file.close();                      
                        
                        if(type.equals("-e")){
                            String ciphertext = encrypt(data, key);
                            String fileData = ciphertext;
                            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile)); //filename specified by the user
                            writer.write(fileData); //write data into a text file
                            writer.close();
                            
                        } else if(type.equals("-d")){
                            String plaintext = decrypt(data, 26 - key);
                            String fileData = plaintext;
                            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile)); //filename specified by the user
                            writer.write(fileData); //write data into a text file
                            writer.close();
                        }
                        else if(type.equals("-c")){
                            String plaintext = bruteforce(data);  
                            String fileData = plaintext;
                            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile)); //filename specified by the user
                            writer.write(fileData); //write data into a text file
                            writer.close();
                        }
                    }
                    catch (FileNotFoundException exception){ //catch if the the file does not exist
                        System.out.println("The filename given does not exist in the local directory. Please try again with a valid filename.\nEx: input.txt");
                    }
                }
                else{ //print out if user input numbers outside 0-25 or non-integer
                    System.out.println("Please enter a secret key in the range (0 - 25)");
                }
            }
            else{ //printout the options for letter types
                System.out.println("Please enter only:\n-e for encryption\n-d for decryption\n-c for a bruteforce crack");
            }
        }
    }
    
    public static String encrypt(String plainText, int secretKey)
    {
        String cipherText = ""; //empty list; store letters in this variable
        int length = plainText.length(); //determine how many characters inside the plaintext
        for(int i = 0; i<length; i++){
            char ch = plainText.charAt(i); //store the position of the character
            if(Character.isLetter(ch)){ //if character is letter do this
                char c = (char)(ch+secretKey);
                if(c>'Z'){ //only working with ASCII uppercase letters
                    cipherText += (char)(ch - (26 - secretKey));
                }
                else{
                    cipherText += c;
                }
            }
            else{ //if character is not a letter, just add the character into the list
                cipherText += ch;
            }
        }
        
        return cipherText;
    }
    
    public static String decrypt(String cipherText, int secretKey)
    {
        return encrypt(cipherText, secretKey); //returns the resulting plaintext after reverse encryption
    }
    
    public static String bruteforce(String cipherText) throws IOException
    {
        FileReader file = new FileReader("dictionary.txt");
        BufferedReader reader = new BufferedReader(file);
        ArrayList<String> dictionary = new ArrayList<String>(); 
        String returnString = "";
        String line = reader.readLine();
        while (line != null){
            dictionary.add(line.replaceAll("\\s+","").toUpperCase());
            line = reader.readLine();
        }
        int Key = 0;
        int matchCount = 0;
        double accuracy;
        String[] plainText;
        System.out.println("Printing all decryptions with atleast a 70% match rate:");
        while (Key < 26)
        {
            plainText = decrypt(cipherText, Key).split(" ");
            for (int i = 0; i < plainText.length; i++){
                if (dictionary.contains(plainText[i])){
                    matchCount++;
                }
            }
            accuracy = ((double) matchCount) / plainText.length;
            if (accuracy > .7){
                for (int j = 0; j < plainText.length; j++){
                    returnString += (plainText[j] + " ");
                    System.out.print(plainText[j] + " ");
                }   
            }
            Key++;
            accuracy = 0;
            matchCount = 0;
        }
        return returnString;
    }
}
