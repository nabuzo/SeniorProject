import java.util.*;
import java.io.*;
import java.math.BigInteger;

/**
 * A simple program to demonstrate the Avalanche Effect of Confusion and 
 * Diffusion in the AES block cipher. 
 *
 * @author (Henry Hetzel and Nicole Abuzo)
 * @version (Submitted on March 29, 2020 Version 1)
 */
public class AvalancheTest
{
    public static void main(String[] args) throws IOException{
        AES encryptAES = new AES(); // create new AES instance
        ArrayList<String> possibleKeys = new ArrayList<String>();
        for(int i = 0; i < 128; i++){
            possibleKeys.add(Integer.toString(i));
        }
        
        
        if(args.length == 4){
            if(args[0].equals("-g") && possibleKeys.contains(args[1])){
                try{
                    int index = Integer.parseInt(args[1]);
                    String outputFile = args[3];
                    ArrayList<String> plaintexts = new ArrayList<String>();
                    String keyText = "";
                    ArrayList<String> keys = new ArrayList<String>();
                    ArrayList<String> ciphertexts = new ArrayList<String>();
                    ArrayList<Integer> bitsFlipped = new ArrayList<Integer>();
                    String inputFile = args[2];
                    FileReader file = new FileReader(inputFile);
                    BufferedReader reader = new BufferedReader(file);
                    
                    String data = ""; //empty
                    String line = reader.readLine();
                    
                    while (line != null){
                        data += line;
                        String[] AESTriples = line.split(" ");
                        if(keyText.equals("")){
                            keyText = AESTriples[0];
                        }
                        keys.add(AESTriples[0]);
                        plaintexts.add(AESTriples[1]);
                        ciphertexts.add(AESTriples[2]);
                        data = "";
                        line = reader.readLine();
                        //split the key text and plain text
                    }
                    
                    file.close(); 
                
                    String plainText;
                    String cipherText;
                    BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile)); //filename specified by the user
                    writer.write("PlainText                            Toggle Bit     # bits flipped in ciphertext\n");

                    for(int j = 0; j< keys.size(); j++){
                        plainText = plaintexts.get(j);
                        cipherText = ciphertexts.get(j);
                        byte[] plain = Util.hex2byteA(plainText);
                        byte[] key = Util.hex2byteA(keyText);
                        byte[] result;
                        encryptAES.setKey(key);
                        result = encryptAES.encrypt(plain);   
                        String cipher = Util.toHEX(result);
                   
                        int byteIndex = index / 8;
                        int bitIndex = 7 - index % 8;
                        plain[byteIndex] = (byte) Util.toggle(plain[byteIndex], bitIndex);
                      
                        String newPlainText = Util.toHEX(plain);
                        String newCipherText = Util.toHEX(encryptAES.encrypt(plain));
                        bitsFlipped.add(hex2Bin.compareString(cipher, newCipherText));
                        
                        writer.write(plainText + "          " + index + "                  " + bitsFlipped.get(j) + "\n");
                        //write data into a text file
                            
                    }
                    writer.close();
                }
                catch(FileNotFoundException exception){
                    System.out.println("The file does not exist. Try again");
                }
            }
            else{
                System.out.println("Incorrect Input(s)\nExpected: -g index(integer 0 - 127) inputfile.txt");
                System.out.println("Actual: " + args[0] + " " + args[1] + " " + args[2]);
            }
        }
        
        else if(args.length == 3){
            if(args[0].equals("-f") && possibleKeys.contains(args[1])){
                try{
                    int index;
                    index = Integer.parseInt(args[1]);
                    String inputFile = args[2];
                    
                    //reading the file
                    FileReader file = new FileReader(inputFile);
                    BufferedReader reader = new BufferedReader(file);
                    String data = ""; //empty
                    String line = reader.readLine();
                    while (line != null){
                        data += line;
                        line = reader.readLine();
                    }
                    //split the key text and plain text
                    String[] value = data.split(" ");
                    String keyText = value[0];
                    String plainText = value[1];       
                    file.close();                       
               
                    byte[] plain = Util.hex2byteA(plainText);
                    byte[] key = Util.hex2byteA(keyText);
                    byte[] result;
               
                    encryptAES.setKey(key);
                    result = encryptAES.encrypt(plain);   
                    String cipher = Util.toHEX(result);
           
                    System.out.println("Key: " + keyText + "\n" + "Plaintext: " + plainText);
                    System.out.println("Ciphertext: " + cipher + "\n" + "Flip bit: " + index);  
               
                    int byteIndex = index / 8;
                    int bitIndex = 7 - index % 8;
                    plain[byteIndex] = (byte) Util.toggle(plain[byteIndex], bitIndex);
              
                    String newPlainText = Util.toHEX(plain);
                    System.out.println("New Plaintext: " + newPlainText);
              
                    String newCipherText = Util.toHEX(encryptAES.encrypt(plain));
                    System.out.println("New Ciphertext: " + newCipherText);
              
                    System.out.println("Number of flipped bits: " + hex2Bin.compareString(cipher, newCipherText));
                }
                catch(FileNotFoundException exception){
                    System.out.println("The file does not exist. Try again");
                }
                
            }
            else if(args[0].equals("-c")){
                try{
                    String inputFile = args[1];
                    String outputFile = args[2];
                    
                    //reading the file
                    FileReader file = new FileReader(inputFile);
                    BufferedReader reader = new BufferedReader(file);
                    String data = ""; //empty
                    String line = reader.readLine();
                    while (line != null){
                        data += line;
                        line = reader.readLine();
                    }
                    //split the key text and plain text
                    String[] value = data.split(" ");
                    String keyText = value[0];
                    String plainText = value[1];       
                    file.close();                       
               
                    byte[] plain = Util.hex2byteA(plainText);
                    byte[] key = Util.hex2byteA(keyText);
                    byte[] result;
               
                    encryptAES.setKey(key);
                    result = encryptAES.encrypt(plain);   
                    String cipher = Util.toHEX(result);
                    
                    BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile)); //filename specified by the user
                    writer.write("Plaintext                           Key\n");
                    writer.write(plainText + "    " + keyText + "\n");
                    writer.write("Plaintext Flip Bit     Number of flipped bits\n");
                    for(int i = 0; i < 128; i++){
                        System.out.println("Key: " + keyText + "\n" + "Plaintext: " + plainText);
                        System.out.println("Ciphertext: " + cipher + "\n" + "Flip bit: " + i);  
                   
                        int byteIndex = i / 8;
                        int bitIndex = 7 - i % 8;
                        plain[byteIndex] = (byte) Util.toggle(plain[byteIndex], bitIndex);
                  
                        String newPlainText = Util.toHEX(plain);
                        System.out.println("New Plaintext: " + newPlainText);
                  
                        String newCipherText = Util.toHEX(encryptAES.encrypt(plain));
                        System.out.println("New Ciphertext: " + newCipherText);
                  
                        System.out.println("Number of flipped bits: " + hex2Bin.compareString(cipher, newCipherText));
                        writer.write(i + "                     " +  hex2Bin.compareString(cipher, newCipherText) + "\n");
                    }
                    writer.close();
                }
                catch(FileNotFoundException exception){
                    System.out.println("The file does not exist. Try again");
                }
            }
            else{
                System.out.println("Incorrect Input(s)\nExpected: -f index(integer 0 - 127) inputfile.txt");
                System.out.println("Or: -c inputfile.txt outputfile.txt");
                System.out.println("Received: " + args[0] + " " + args[1] + " " + args[2]);
            }
        }
        else{
            System.out.println("Incorrect number of arguments");
        }
        
    }
    
   //count the number of flipped bits using compare string method
   public static class hex2Bin{
       static BigInteger HtoB(String a) {
           return new BigInteger(a,16);
       }
       static String BtoH(String a) {
           return new BigInteger(a, 2).toString(16);
       }
       static int compareString(String a1, String a2){
           BigInteger a1Bit = HtoB(a1);
           BigInteger a2Bit = HtoB(a2);
           BigInteger XOR = a1Bit.xor(a2Bit);

           return XOR.bitCount();
        }
    }
}
